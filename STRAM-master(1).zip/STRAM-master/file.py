import pyqtgraph as pg
import numpy as np
from PyQt5.QtCore import QTimer, Qt, QEvent, QObject, QCoreApplication
from PyQt5.QtGui import QKeyEvent, QKeySequence
from PyQt5.QtWidgets import QApplication
import sys
import os


zz= int(sys.argv[1])
# print(zz)

selected_channels = [int(arg) for arg in sys.argv[1:]]
# with open('settings.txt', 'r') as f:
#     lines = f.readlines()
#     b = int(lines[-1]) 
#     print(b)

count = 0
data = []
if zz!=2:
    raw = "raw.txt"
    print("Board 1")
else:
    raw = "raw2.txt"
    print("Board 2")
    


with open(raw, 'r') as f: 
    for line in f: 
        line = line.strip().split(',') 
        line = [x for x in line if x!='']
       
        try:
            m = np.array(line, dtype=float)
            if m.size==19:
                data.append(m)
        except Exception as e:
            count += 1
            continue    

arr = np.vstack(data)

class MyPlotWidget(pg.PlotWidget, QObject):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.installEventFilter(self)
        self.paused = False
    
    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress:
            key = event.key()
            if key == Qt.Key_Space:
                self.paused = not self.paused
        return False

app = pg.mkQApp("My Plot")
win = MyPlotWidget(title="My Plot")
win.show()
win.setWindowTitle('My Plot')


y_min = np.nanmin(arr[:, np.array(selected_channels)-1])
y_max = np.nanmax(arr[:, np.array(selected_channels)-1])
win.setYRange(y_min, y_max)

x_min = 0
x_max = len(data)
win.setXRange(x_min, x_max)

legend = win.addLegend()

curves = []

for i, channel in enumerate(selected_channels):
    curve = win.plot(pen=pg.intColor(i), name=f'Channel {channel}')
    curves.append(curve)
    
for i in selected_channels:
    count+=1
    if count>=len(selected_channels):
        break
    legend.addItem(curve, f'Channel {channel}')
    

# Add grid lines to the plot
grid = pg.GridItem()
win.addItem(grid)

timer = pg.QtCore.QTimer()
i = 0

def update():
    global i, arr, curves, win
    if win.paused:
        return
    if i >= len(arr):
        timer.stop()
        return
    x = np.arange(i+1)
    for j, curve in enumerate(curves):
        channel_data = arr[: i + 1, np.array(selected_channels[j])-1]
        curve.setData(x, channel_data)
    win.setXRange(max(0, i - len(data) + 100), i + 100)

    i += 1

timer.timeout.connect(update)

timer.start(1)

if __name__ == '__main__':
    if sys.flags.interactive != 1:
        QApplication.instance().exec_()


















