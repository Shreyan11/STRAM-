







#include<sstream>



#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include <vector>

#include <winsock2.h>
#include <ws2tcpip.h>

#define MAX_CLIENTS 10
#define BUFFER_SIZE 1120

using namespace std;

int main(int argc, char* argv[]) {
  WSADATA wsaData;
  int listen_fd, conn_fd;
  struct sockaddr_in serv_addr;
  char buffer[BUFFER_SIZE];
  int count2=0,n=1;
  string filename = "raw.txt";
  ofstream outfile;
  std::vector<float> avg(16, 0);
  int b=0,nn=0,count = 0;
  vector<vector<float>> values2;
  vector<float> values;
  int j=0;
  int count3 =0;
  int row =0;
  float float_value;

  if (argc < 2) {
    std::cout << "ERROR: Argument passing error" << endl;
    return 1;
  }

  WSAStartup(MAKEWORD(2, 2), &wsaData);

  listen_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  memset(&serv_addr, '0', sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(atoi(argv[1]));
  int flag =0;

  if (bind(listen_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR) {
    std::cout << "Bind failed with error " << WSAGetLastError() << endl;
    return 1;
  }

  if (listen(listen_fd, MAX_CLIENTS) == SOCKET_ERROR) {
    std::cout << "Listen failed with error " << WSAGetLastError() << endl;
    return 1;
  }

  std::cout << "DAQ server started on port " << atoi(argv[1]) << endl;

  outfile.open("raw.txt", ios::app);
  ofstream csv("");
  csv.open("cleaned.txt",ios::app);
  conn_fd = accept(listen_fd, (struct sockaddr*)NULL, NULL);
   for (int i = 1; i <= 16; i++) {
    csv<< "Channel " << i << ",";
  }
  csv << '\n'; 
  fd_set readfds;
  timeval tv;
  tv.tv_sec = 0;
  tv.tv_usec = 0;

  // while (n = recv(conn_fd, buffer, BUFFER_SIZE,0)>0) {

    while(1){
    FD_ZERO(&readfds);
    FD_SET(conn_fd, &readfds);

    int result = select(0, &readfds, NULL, NULL, &tv);
    if (result == SOCKET_ERROR) {
      std::cout << "Select failed with error " << WSAGetLastError() << endl;
      break;
    } 
    n = recv(conn_fd, buffer, BUFFER_SIZE,0);
    if(n==0)
      break;

    outfile << buffer;
    stringstream ss(buffer);
    //vector<float> row;
    string value;
      //while (std::getline(input_file, line)) {
    std::vector<float> values;
    //std::vector<float> values2;
    //std::stringstream ss(line);
    //std::string value;
    while (std::getline(ss, value, ',')) {

        
         if(value == "0" ){
       
             continue;
         }
        
        //   else if (value == "\n"){
        //     std::cout<<"yeet";
        //   }  
      try {
        float_value = std::stof(value);
        if(float_value == 0)
            continue;
        
        count2+=1;
        values.push_back(float_value);
        if(count2<1600);
        {
          avg[count] += float_value;
          count+=1;
          if(count>15){count=0;
          //cout<<avg[0]<<"\n";
          }else{
            flag =1;
          }
        }

      

        
      } catch (const std::invalid_argument& e) {
        //std::cout<< "  Unable to convert"<<value<<"to float";
        // return 1;
        continue;
      }

      if(flag=1){
      for(int j=0;j<16;j++){
        avg[j]=avg[j]/100;
        //cout<<j<<"  "<<avg[j]<<"\n";


      }
      flag =2;
      } 

    if(flag =2){
    //for (auto v : values) {
      csv << float_value - avg[count3]<< ",";
      count3+=1;
      if(count3> 15){
      csv<<"\n";
      count3 = 0;
      }
    //}
    }


    }

    //if(count> 1600 ){

      // for(j=0;j<15;j++){
      //  for(int i=0;i<100;i++){

      //   avg[j]+= values2[j][i];
      //   //j++;
      //   //if(j%16==0)j=0;
          
      //  }
          

      

      
      //std::cout<<j<<" "<<avg[j]<<"\n";
        //}
        //flag =1;
    //continue;
    //  }


    //}
    
    //}//for(){
    //values[nn]-= avg[nn-16];
    


    //output_file << channel << ",";

    //}
     //std::cout << "Received with " << n << endl;
    //channel++;
    std::cout << "Received with " << n << endl;

    
  }
  
    // if(flag =1){
    // for (auto v : values) {
    //   csv << v - avg[count3]<< ",";
    //   count3+=1;
    //   if(count3  % 16 == 0){
    //   csv<<"\n";
    //   count3 = 0;
    //   }
    // }
    // }



//here
    //string temp = "";
    // for (int i = 0; i < n; i++) {
    //   //string temp = buffer[i];
    //   //if (c == ',' || c == '\n') {
    //     if (c == '0') {
    //         continue;
    //     }

    //       try {
    //         float value = stof(string(1,c));
    //         //csv<<value<<","
    //       } catch (const invalid_argument& e) {
    //         cerr << "Error: Unable to convert  "<< c << " to float\n";
    //       }
        
        //temp = "";
      //} else {
      //  temp += c;
      //}
    
    //values.push_back(row);

    

  // Write the contents of the vector to a CSV file
  
  //for (auto& row : values) {
    // for (size_t i = 0; i < row.size(); i++) {
    //   csv_file << row[i]<<",";
     
    // }
    // csv_file<<"\n";
  

  
  

    
    csv.close();
    closesocket(conn_fd);
  WSACleanup();
  return 0;
}
