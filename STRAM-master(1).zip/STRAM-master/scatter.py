import pyqtgraph as pg
import numpy as np
import time

count = 0
data = []
with open('raw.txt', 'r') as f:
    for line in f:
        line = line.strip().split(',')
        line = [x for x in line if x != '']
        try:
            m = np.array(line, dtype=float)
            if m.size == 19:
                data.append(m)
        except Exception as e:
            count += 1
            continue

arr = np.vstack(data)

app = pg.mkQApp("My Plot")
win = pg.PlotWidget(title="My Plot")
win.show()
win.setWindowTitle('My Plot')
win.setLabel('left', 'column 6')
win.setLabel('bottom', 'column 7')

y_min = np.nanmin(arr[:, 6])
y_max = np.nanmax(arr[:, 6])
win.setYRange(y_min, y_max)

x_min = np.nanmin(arr[:, 7])
x_max = np.nanmax(arr[:, 7])
win.setXRange(x_min, x_max)

spots = pg.ScatterPlotItem(size=10, pen=pg.mkPen(None), brush=pg.mkBrush(255, 255, 255, 120))
spots.addPoints(arr[:, 5], arr[:, 6])

win.addItem(spots)

pg.QtGui.QGuiApplication.exec_()


