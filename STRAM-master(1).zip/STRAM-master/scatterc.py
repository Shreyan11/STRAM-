import pyqtgraph as pg
import numpy as np
import sys

# Read x and y axis from command line arguments
if len(sys.argv) < 3:
    print("Please specify x and y axis as command line arguments")
    sys.exit()
x_axis = int(sys.argv[1])
y_axis = int(sys.argv[2])
zz = int(sys.argv[3])
print(zz)
count = 0
data = []

if zz!=2:
    raw = "raw.txt"
    print("Board 1")
else:
    raw = "raw2.txt"
    print("Board 2")



with open(raw, 'r') as f:
    for line in f:
        line = line.strip().split(',')
        line = [x for x in line if x != '']
        try:
            m = np.array(line, dtype=float)
            if m.size == 19:
                data.append(m)
        except Exception as e:
            count += 1
            continue

arr = np.vstack(data)
# print(count)

app = pg.mkQApp("Scatter plot")
win = pg.PlotWidget(title="Scatter plot")
win.show()
win.setWindowTitle('Scatter Plot')

# Add a grid
grid = pg.GridItem()
win.addItem(grid)

win.setLabel('left', f'column {y_axis}')
win.setLabel('bottom', f'column {x_axis}')

spots = pg.ScatterPlotItem(size=10, pen=pg.mkPen(None), brush=pg.mkBrush(255, 255, 255, 120))
spots.addPoints(arr[:, x_axis - 1], arr[:, y_axis - 1])

win.addItem(spots)

# Set autoRange to True
win.autoRange()

pg.QtGui.QGuiApplication.exec_()
