import tkinter as tk
from tkinter import messagebox
import os


class SettingsWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Settings")
        self.geometry("800x350")

        # Set up variables
        self.scatter_x_var = tk.StringVar()
        self.scatter_y_var = tk.StringVar()
        self.boxes_var = tk.StringVar()
        self.time_vars = [tk.BooleanVar(value=False) for _ in range(16)]

        # Set up grid layout
        self.grid_columnconfigure(0, weight=1)
        for i in range(9):
            self.grid_rowconfigure(i, weight=1)

        # Set up scatter x dropdown
        scatter_x_label = tk.Label(self, text="Scatter X Plot", font=("Arial", 12))
        scatter_x_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        scatter_x_options = ["{}".format(i+1) for i in range(16)]
        scatter_x_dropdown = tk.OptionMenu(self, self.scatter_x_var, *scatter_x_options)
        scatter_x_dropdown.config(font=("Arial", 12), width=20)
        scatter_x_dropdown.grid(row=0, column=1, padx=10, pady=10, sticky="e")

        # Set up scatter y dropdown
        scatter_y_label = tk.Label(self, text="Scatter Y Plot", font=("Arial", 12))
        scatter_y_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")
        scatter_y_options = ["{}".format(i+1) for i in range(16)]
        scatter_y_dropdown = tk.OptionMenu(self, self.scatter_y_var, *scatter_y_options)
        scatter_y_dropdown.config(font=("Arial", 12), width=20)
        scatter_y_dropdown.grid(row=1, column=1, padx=10, pady=10, sticky="e")

        # Set up boxes dropdown
        boxes_label = tk.Label(self, text="Box No.", font=("Arial", 12))
        boxes_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")
        boxes_options = ["{}".format(i+1) for i in range(16)]
        boxes_dropdown = tk.OptionMenu(self, self.boxes_var, *boxes_options)
        boxes_dropdown.config(font=("Arial", 12), width=20)
        boxes_dropdown.grid(row=2, column=1, padx=10, pady=10, sticky="e")

        # Set up time plot checkboxes
        time_label = tk.Label(self, text="Time Plot Channels:", font=("Arial", 12))
        time_label.grid(row=3, column=0, padx=10, pady=10, sticky="w")
        for i, var in enumerate(self.time_vars):
            cb = tk.Checkbutton(self, text=f"Channel {i+1}", variable=var, font=("Arial", 12))
            cb.grid(row=4+i//4, column=i%4, padx=10, pady=5, sticky="w")

        # Set up save button
        save_button = tk.Button(self, text="Save", command=self.handle_save, font=("Arial", 14))
        save_button.grid(row=8, column=0, columnspan=2, padx=10, pady=(50,10), sticky="nsew")

    def handle_save(self):
        # Check if scatter x and scatter y dropdowns have the same selection
        if self.scatter_x_var.get() == self.scatter_y_var.get():
            error_message = messagebox.showerror("Error", "Scatter X and Scatter Y cannot have the same channel selected.")
            return
            
        # Save settings to file
        with open("settings.txt", "w") as f:
            f.write(f"Scatter X: {self.scatter_x_var.get()}\n")
            f.write(f"Scatter Y: {self.scatter_y_var.get()}\n")
            f.write("Time Plot Channels:\n")
            for i, var in enumerate(self.time_vars):
                if var.get():
                    f.write(f"{i+1}\n")

        # Close window
        print("Settings saved.")
        self.destroy()
        os._exit(0)


if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()

    settings_window =SettingsWindow(root)
    root.mainloop()








