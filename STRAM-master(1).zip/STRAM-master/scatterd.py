import pyqtgraph as pg
import numpy as np
import time

# Read axis values from file
with open('settings.txt', 'r') as f:
    x_axis = int(f.readline().split(':')[-1].strip())
    y_axis = int(f.readline().split(':')[-1].strip())


with open('settings.txt', 'r') as f:

    lines = f.readlines()
    zz = int(lines[-1]) 
    print(zz)

if zz!=2:
    raw = "raw.txt"
    print("Board 1")
else:
    raw = "raw2.txt"
    print("Board 2")
    
# Read data from file
count = 0
data = []
with open(raw, 'r') as f:
    for line in f:
        line = line.strip().split(',')
        line = [x for x in line if x != '']
        try:
            m = np.array(line, dtype=float)
            if m.size == 19:
                data.append(m)
        except Exception as e:
            count += 1
            continue

arr = np.vstack(data)
print(count)
app = pg.mkQApp("My Plot")
win = pg.PlotWidget(title="My Plot")
win.show()
win.setWindowTitle('My Plot')

# Add a grid
grid = pg.GridItem()
win.addItem(grid)

win.setLabel('left', f'column {y_axis}')
win.setLabel('bottom', f'column {x_axis}')

spots = pg.ScatterPlotItem(size=10, pen=pg.mkPen(None), brush=pg.mkBrush(255, 255, 255, 120))
spots.addPoints(arr[:, x_axis-1], arr[:, y_axis-1])

win.addItem(spots)

# Set autoRange to True
win.autoRange()

pg.QtGui.QGuiApplication.exec_()
