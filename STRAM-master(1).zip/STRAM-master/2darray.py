import pyqtgraph as pg
import numpy as np
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QApplication, QMainWindow
import sys


class GraphWindow(QMainWindow):
    def __init__(self, arr, column):
        super().__init__()
        self.setWindowTitle(f"Column {column}")
        self.column = column

        # Set up the plot widget
        self.plot_widget = pg.PlotWidget(title=f"Column {column}")
        self.setCentralWidget(self.plot_widget)

        # Set the x-axis and y-axis ranges
        y_min = np.nanmin(arr[:, column])
        y_max = np.nanmax(arr[:, column])
        self.plot_widget.setYRange(y_min, y_max)
        self.plot_widget.setXRange(0, len(arr))

        # Add the data curves
        self.curve = self.plot_widget.plot(pen='b', name=f"Column {column}")

        # Set up the timer
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.i = 0
        self.paused = False

    def start(self):
        self.timer.start(100)

    def update(self):
        if self.paused:
            return
        if self.i >= len(arr):
            self.timer.stop()
            return
        data = arr[: self.i + 1, self.column]
        self.curve.setData(data)
        self.plot_widget.setXRange(max(0, self.i - 100), self.i)
        self.i += 1

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Space:
            self.paused = not self.paused


if __name__ == '__main__':
    # Load the data
    data = []
    with open('raw.txt', 'r') as f:  # opens the raw file
        for line in f:
            line = line.strip().split(',')
            line = [x for x in line if x != '']
            try:
                m = np.array(line, dtype=float)
                if m.size == 19:
                    data.append(m)
            except Exception as e:
                print(e)
                continue
    arr = np.vstack(data)

    # Create the application and windows
    app = QApplication(sys.argv)

    windows = []
    for i in range(3, 19):
        window = GraphWindow(arr, i)
        window.show()
        windows.append(window)

    # Start the timers
    for window in windows:
        window.start()

    # Set up the keyboard shortcut to pause/resume all windows
    app.focusChanged.connect(lambda: windows[0].setFocus())
    app.keyPressEvent = lambda event: [window.keyPressEvent(event) for window in windows]

    # Run the application
    sys.exit(app.exec_())
