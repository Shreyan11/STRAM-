# Socket server in python using select function

import socket, select
import sys
import os
import time
import struct
import chardet
import string
import numpy as np

def main():
    CONNECTION_LIST = []    # list of socket clients
    RECV_BUFFER = 161 # 100K file
    n = len(sys.argv)
    if n < 1:
        print("Argument passing error")
        return
    PORT = int(sys.argv[1])

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.settimeout(60)
    count =0
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(("0.0.0.0", PORT))
    server_socket.listen(10)
    lst = []
    mega = [0.0,1.0,2.0,3.0,4,5,6,7,8,9,10,11,12,13,14,15,16]
    flag = True
    print("DAQ server started on port " + str(PORT))
    # dirpath = os.getcwd()
    # timenow = time.strftime("%Y%m%d-%H%M%S")
    # Filename = "dirpath+"\datalog-"+sys.argv[1]+"-"+timenow+".csv""
    # file2 = open(Filename,"w+")
    # fileopen = True
    # try:
    #while flag == True:
    
    sockfd, addr = server_socket.accept()
    sockfd.settimeout(60)
    sockfd.setblocking(0)
    print("Client (%s, %s) connected" % addr)
    while True:
        

        try:
                bytes_to_receive = RECV_BUFFER
                data = sockfd.recv(RECV_BUFFER)
                data = b""
                while bytes_to_receive > 0:
                    count+=1
                    chunk = sockfd.recv(bytes_to_receive)
                    data += chunk
                    bytes_to_receive -= len(chunk)
    # if not chunk:
                #print(ord(data))
                #print(len(data))
                if len(data) > 0:
                    #detected_encoding = chardet.detect(data)['encoding']
                    #print(detected_encoding)
                    # if(len(data)==1120):
                    data_str = data.decode('utf-8')
                    # data_str = data_str.replace("\n", "")
                    #print(len(data_str))
                    
                    print(data_str)
                    print("yeet13")
                    data = None
                    # string1 =''
                    # string1+=data_str
                    # string1.strip()
                    # print(string1)

##################################################################################################
                    
                    #my_array = np.fromstring(data_str, dtype=float, sep=',')

                    
                    #for x in my_array:
                         #if(len(x)<8):
                               # print(x)
                    #         #print(my_array[i]) 
                    #         #if len(all[i])!=8):
                            
                    #         lst.append(x)
                    #         if(len(lst)>18):
                    #              print(lst)
                    #              lst.clear()
                    
                                 
                            
                        
                     
                        
                            
                    #     #     #print(type(item))
                    #     # #lst.append(x)
                        
                    #     #     # lst.pop()
                    #     #     # print(lst)
                    #         if(len(lst)>18):
                    #               print(lst)
                    #               lst.clear()
                        #if(len(lst)>18):
                             #lst = np.lst
                        #     f = lst.astype(float)
                        #     print(f)
                        # #      t = np.array(lst)
                        #    print(lst)
                        #      #print("\n")
                        #     #  np.vstack(mega,t)
                            #lst.clear()
                        #     f.clear()
                             #print(lst)
                             #print("clear")
                            #  rows, cols = mega.shape

                            #  print(rows)
                            #  print(cols)
                        #count+=1
                        



                        #print(x)
                        # print(item + "\t" + ord(item))
                        
                           
                else:
                        print("Client (%s, %s) disconnected" % addr)
                        sockfd.close()
                        break
        except socket.timeout:
            print("Socket timeout")
            # file2.close()
            #fileopen=False
            pass
        except Exception as e:
            if "could not convert string to float:" in str(Exception):
            # print("Client (%s, %s) is offline" % addr)
            #sockfd.close()
                print("couldnt convert")
                continue
        
        #for x in lst:
            #print(x)    
        # dataf = struct.unpack('ff', data)
        # for item in data_str.strip().split(','):
                # lst.append(float(item.strip('"')))
                # print(item)
        #print(data)

            # file2.write(data.decode('utf8'))
            
            #except socket.timeout:
            #    print("Socket timeout")
                # file2.close()
                #fileopen=False
                #pass
            #except:
            #    print("Client (%s, %s) is offline" % addr)
            #    sockfd.close()
            #    # file2.close()
            #    fileopen=False
    # except socket.timeout:
    #     server_socket.close()
    #     pass 
    # except:            
    #     print("exit form main Loop")  
    #     sockfd.close() 
    #     if fileopen == True:
    #         file2.close()        
        


if __name__ == "__main__":
    main()