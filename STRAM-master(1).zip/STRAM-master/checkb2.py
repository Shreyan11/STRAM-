import tkinter as tk
from tkinter import ttk
import subprocess

root = tk.Tk()
root.title("Select the channels")

# Scatter 1 Checkboxes
scatter1_label = tk.Label(root, text="Scatter X axis")
scatter1_label.grid(row=0, column=0, columnspan=4, pady=5)

checkboxes1 = []
selected1 = tk.StringVar()

def on_checkbox1_select():
    for i in range(16):
        if checkboxes1[i].cget("text") == selected1.get():
            checkboxes1[i].select()

def on_checkbox2_select():
    for i in range(16):
        if checkboxes2[i].cget("text") == selected2.get():
            checkboxes2[i].select()

for i in range(16):
    checkbox = tk.Checkbutton(root, text=f"Channel {i+1}", variable=selected1, onvalue=f"Channel {i+1}", offvalue="", command=on_checkbox1_select)
    checkbox.grid(row=(i//4)+1, column=i%4, pady=5, sticky="nsew")
    checkboxes1.append(checkbox)

# Scatter 2 Checkboxes
scatter2_label = tk.Label(root, text="Scatter Y axis")
scatter2_label.grid(row=18, column=0, columnspan=4, pady=5)

checkboxes2 = []
selected2 = tk.StringVar()

for i in range(16):
    checkbox = tk.Checkbutton(root, text=f"Channel {i+1}", variable=selected2, onvalue=f"Channel {i+1}", offvalue="", command=on_checkbox2_select)
    checkbox.grid(row=(i//4)+19, column=i%4, pady=5, sticky="nsew")
    checkboxes2.append(checkbox)


# Board Dropdown and Generate Button
frame = tk.Frame(root, bg="#f0f0f0")
frame.grid(row=40, column=0, columnspan=4, pady=10)

options = ["Board 1", "Board 2", "Board 3", "Board 4", "Board 5", "Board 6", "Board 7", "Board 8", "Board 9", "Board 10"]
selected_option = tk.StringVar()

dropdown = ttk.Combobox(frame, textvariable=selected_option, values=options, state="readonly")
dropdown.current(0)
dropdown.pack(side=tk.LEFT, padx=5)

error_label = tk.Label(frame, fg="red")
error_label.pack(side=tk.RIGHT, padx=20)

def send_selected():
    selected1_value = selected1.get()
    selected2_value = selected2.get()

    if selected1_value == "" or selected2_value == "":
        error_label.config(text="Error: You must select a channel in both Scatter 1 and Scatter 2")
    elif selected1_value == selected2_value:
        error_label.config(text="Error: Same channel cannot be selected in both Scatter 1 and Scatter 2")
    else:
        scatter1 = selected_option.get()
        scatter2 = selected_option.get()
        channels = [int(selected1_value.split()[1]), int(selected2_value.split()[1])]
        
        print(f"{channels}")
        subprocess.Popen(["python", "scatterc.py", str(channels[0]), str(channels[1])])

next_button = tk.Button(frame, text="Generate", bg="#00b300", fg="white", font=("Arial", 12), command=send_selected)
next_button.pack(side=tk.LEFT, pady=5, padx=20)

root.mainloop()
