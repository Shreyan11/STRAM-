import tkinter as tk
from tkinter import ttk
import os
import subprocess
count =0
window = tk.Tk()
window.geometry("700x500")
window.title("STRAM")
count = 0
label = tk.Label(text="STRAM 1.0",  height = 15,font=("Helvetica", 16 ))
label.pack()
label1 = tk.Label(text="Loading..",font=("Helvetica", 8 ))
label1.pack()
progress_bar = ttk.Progressbar(window, orient="horizontal", length=500, mode="determinate")
progress_bar.pack(pady=10)


def update_progress_bar():
    # progress_bar.step(5)
    # window.after(50, update_progress_bar)
    # count+=1
    global count
    if(count > 3):
        progress_bar.step(10)
        window.after(100, update_progress_bar)
        count+=1
        if count>8:
            window.destroy()
            subprocess.Popen(["python","ui.py"])
            
            
        

    else:
        progress_bar.step(5)
        window.after(500, update_progress_bar)
        count+=1
        
    

update_progress_bar()

window.mainloop()











#1 : absolutely essential for window,creating an instancs of .tk class
# .mainloop : also essential for creating a basic window
















# import tkinter as tk
# from tkinter import ttk

# window = tk.Tk()

# # create label and set its text
# loading_label = tk.Label(text="Loading",height= 5,width= 10)
# loading_label.pack()

# # add a progress bar to indicate loading progress
# progress_bar = ttk.Progressbar(window, orient="horizontal", length=300, mode="determinate")
# progress_bar.pack(pady=10)

# # function to update the progress bar value
# def update_progress_bar():
#     progress_bar.step(10)
#     window.after(50, update_progress_bar) # call this function again after 500ms

# # call the function to update progress bar repeatedly
# update_progress_bar()

# window.mainloop() # start the GUI event loop to display the window and the progress bar
