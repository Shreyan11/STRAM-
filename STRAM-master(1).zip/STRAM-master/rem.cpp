#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

int main() {
  std::ifstream input_file("raw.txt");
  std::ofstream output_file("cleaned.csv");

  if (!input_file.is_open() || !output_file.is_open()) {
    std::cerr << "Error: Unable to open file(s)\n";
    return 1;
  }

  //output_file << "Channel,";
  for (int i = 1; i <= 16; i++) {
    output_file << "Channel " << i << ",";
  }
  output_file << '\n';

  std::string line;
  int channel = 1;
  while (std::getline(input_file, line)) {
    std::vector<float> values;
    std::stringstream ss(line);
    std::string value;
    while (std::getline(ss, value, ',')) {
         if(value == "0")
             continue;
      try {
        float float_value = std::stof(value);
        values.push_back(float_value);
      } catch (const std::invalid_argument& e) {
        std::cerr << "Error: Unable to convert '" << value << "' to float\n";
        // return 1;
        continue;
      }
    }

    //output_file << channel << ",";
    for (const auto& v : values) {
      output_file << v << ",";
    }
    output_file << '\n';
    //channel++;
  }

  input_file.close();
  output_file.close();

  return 0;
}
