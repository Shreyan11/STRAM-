# STRAM
GUI for MNIT-Jaipur 160Channel DAQ


Each time You run,make sure you add -l ws2_32 in the g++ command

For example, to compile server2.cpp,you need to put g++ -o server server2.cpp -l ws2_32
