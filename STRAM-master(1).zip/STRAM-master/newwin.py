
from tkinter import messagebox as tkmessagebox
import multiprocessing
import tkinter as tk
import os
import subprocess
class MyUI(tk.Frame):
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)
        self.master = master
        self.master.title("New Project")
        self.master.configure(bg='#F5F5F5')
        self.folder_path = None

        self.name_label = tk.Label(self.master, text="Name:", bg='#F5F5F5', font=('Arial', 14))
        self.name_entry = tk.Entry(self.master, width=30, font=('Arial', 14))
        self.description_label = tk.Label(self.master, text="Description:", bg='#F5F5F5', font=('Arial', 14))
        self.description_entry = tk.Text(self.master, width=30, height=5, font=('Arial', 14))

        self.next_button = tk.Button(self.master, text="Next", bg='#4CAF50', fg='white', font=('Arial', 14), command=self.create_folder_and_file)

        self.name_label.grid(row=0, column=0, sticky="e", padx=10, pady=10)
        self.name_entry.grid(row=0, column=1, padx=10, pady=10)
        self.description_label.grid(row=1, column=0, sticky="e", padx=10, pady=10)
        self.description_entry.grid(row=1, column=1, padx=10, pady=10)
        self.next_button.grid(row=2, column=1, pady=20)

    def create_folder_and_file(self):
        name = self.name_entry.get()
        #description = self.description_entry.get("1.0", "end-1c") 

        if not name:  # Check if name field is empty
            tkmessagebox.showerror("Error", "Please enter a name.")
            return
        
        # Create folder with the entered name
        self.folder_path = os.path.join(os.getcwd(), name)
        os.makedirs(self.folder_path)

        # Create file with the entered name
        file_path = os.path.join(self.folder_path, "raw.txt")
        # with open(file_path, "w") as f:
        #     f.write(f"Name: {name}\nDescription: {description}")

        self.open_new_window()

    # def open_new_window(self):
        
    #     os.system("python filedef.py")
    #     os.system("python checkb.py")
    def open_new_window(self):
        subprocess.Popen(["python", "checkb.py"])
        subprocess.Popen(["python", "filedef.py"])
        subprocess.Popen(["python", "checkb2.py"])
        subprocess.Popen(["python", "scatterd.py"])



def main():
    root = tk.Tk()
    root.geometry("400x300")
    app = MyUI(master=root)
    app.mainloop()

if __name__ == '__main__':
    main()
