







#include<sstream>



#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include <vector>

#include <winsock2.h>
#include <ws2tcpip.h>

#define MAX_CLIENTS 10
#define BUFFER_SIZE 1120

using namespace std;

int main(int argc, char* argv[]) {
  WSADATA wsaData;
  int listen_fd, conn_fd;
  struct sockaddr_in serv_addr;
  char buffer[BUFFER_SIZE];
  int count2=0,n=1;
  string filename = "raw.txt";
  ofstream outfile;
  int b=0,nn=0,count = 0;
  vector<vector<float>> values;

  if (argc < 2) {
    cout << "ERROR: Argument passing error" << endl;
    return 1;
  }

  WSAStartup(MAKEWORD(2, 2), &wsaData);

  listen_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  memset(&serv_addr, '0', sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(atoi(argv[1]));

  if (bind(listen_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR) {
    cout << "Bind failed with error " << WSAGetLastError() << endl;
    return 1;
  }

  if (listen(listen_fd, MAX_CLIENTS) == SOCKET_ERROR) {
    cout << "Listen failed with error " << WSAGetLastError() << endl;
    return 1;
  }

  cout << "DAQ server started on port " << atoi(argv[1]) << endl;

  outfile.open("raw.txt", ios::app);
  ofstream csv("");
  csv.open("cleaned.csv",ios::app);
  conn_fd = accept(listen_fd, (struct sockaddr*)NULL, NULL);
   for (int i = 1; i <= 16; i++) {
    csv<< "Channel " << i << ",";
  }
  csv << '\n'; 
  fd_set readfds;
  timeval tv;
  tv.tv_sec = 0;
  tv.tv_usec = 0;

  while (1) {
    FD_ZERO(&readfds);
    FD_SET(conn_fd, &readfds);

    int result = select(0, &readfds, NULL, NULL, &tv);
    if (result == SOCKET_ERROR) {
      cout << "Select failed with error " << WSAGetLastError() << endl;
      break;
    } 
    n = recv(conn_fd, buffer, BUFFER_SIZE,0);
    if(n==0)
      break;

    outfile << buffer;
    stringstream ss(buffer);
    //vector<float> row;
    string value;
      //while (std::getline(input_file, line)) {
    std::vector<float> values;
    //std::stringstream ss(line);
    //std::string value;
    while (std::getline(ss, value, ',')) {

         if(value == "0" ){
       
             continue;
         }
        
        //   else if (value == "\n"){
        //     cout<<"yeet";
        //   }  
      try {
        float float_value = std::stof(value);
        if(float_value == 0)
            continue;
        values.push_back(float_value);
      } catch (const std::invalid_argument& e) {
        cout<< "  Unable to convert"<<value<<"to float";
        // return 1;
        continue;
      }
    }

    //output_file << channel << ",";
    for (const auto& v : values) {
      csv << v << ",";
      count2+=1;
      if(count2  % 16 == 0)
      csv<<"\n";
    }
    
    //channel++;
  }

    //string temp = "";
    // for (int i = 0; i < n; i++) {
    //   //string temp = buffer[i];
    //   //if (c == ',' || c == '\n') {
    //     if (c == '0') {
    //         continue;
    //     }

    //       try {
    //         float value = stof(string(1,c));
    //         //csv<<value<<","
    //       } catch (const invalid_argument& e) {
    //         cerr << "Error: Unable to convert  "<< c << " to float\n";
    //       }
        
        //temp = "";
      //} else {
      //  temp += c;
      //}
    
    //values.push_back(row);

    cout << "Received with " << n << endl;

  // Write the contents of the vector to a CSV file
  
  //for (auto& row : values) {
    // for (size_t i = 0; i < row.size(); i++) {
    //   csv_file << row[i]<<",";
     
    // }
    // csv_file<<"\n";
  

  
  
    closesocket(conn_fd);
  WSACleanup();
  return 0;
}

