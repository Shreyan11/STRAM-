import tkinter as tk
import os

class StramUI(tk.Frame):
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)
        self.master = master
        self.master.geometry("500x500")
        
        
        menu_bar = tk.Menu(self.master)
        

        file_menu = tk.Menu(menu_bar, tearoff=0)
        file_menu.add_command(label='New', command=self.open_new_window)
        file_menu.add_command(label='Open', command=self.open_explorer)
        menu_bar.add_cascade(label='File', menu=file_menu)
        
        
        setting_menu = tk.Menu(menu_bar, tearoff=0)
        setting_menu.add_command(label='Settings')
        menu_bar.add_cascade(label='Setting', menu=setting_menu)
        
        
        self.master.config(menu=menu_bar)
        
    def open_new_window(self):
        os.system("python newwin.py")
        
    def open_explorer(self):
        os.startfile(os.getcwd())
        
def main():
    root = tk.Tk()
    app = StramUI(master=root)
    app.mainloop()

if __name__ == '__main__':
    main()
