import pyqtgraph as pg
import numpy as np
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
import tkinter as tk
from tkinter import ttk
import sys

class PlotWindow(QWidget):
    def __init__(self, filename='raw.txt', num_columns=3):
        super().__init__()
        self.filename = filename
        self.num_columns = num_columns
        self.paused = False
        self.data = []
        self.read_data()
        self.init_ui()

    def read_data(self):
        with open(self.filename, 'r') as f:
            for line in f:
                line = line.strip().split(',')
                line = [x for x in line if x != '']
                try:
                    m = np.array(line, dtype=float)
                    if m.size == self.num_columns:
                        self.data.append(m)
                except:
                    continue
        self.arr = np.vstack(self.data)

    def init_ui(self):
        self.setWindowTitle('My Plot')

        self.plot_widget = pg.PlotWidget(title="My Plot")
        y_min = np.nanmin(self.arr[:, 1:])
        y_max = np.nanmax(self.arr[:, 1:])
        self.plot_widget.setYRange(y_min, y_max)

        x_min = 0
        x_max = len(self.data)
        self.plot_widget.setXRange(x_min, x_max)

        self.curves = [self.plot_widget.plot(pen='b', name='Column {}'.format(i+2)) for i in range(self.num_columns-1)]

        self.timer = QTimer()
        self.i = 0

        vbox = QVBoxLayout()

        self.pause_button = QPushButton('Pause')
        self.pause_button.clicked.connect(self.toggle_pause)
        vbox.addWidget(self.pause_button)

        self.setLayout(vbox)

        self.timer.timeout.connect(self.update)
        self.timer.start(100)

    def update(self):
        if self.paused:
            return
        if self.i >= len(self.arr):
            self.timer.stop()
            return
        for j in range(self.num_columns-1):
            col = self.arr[: self.i + 1, j+1]
            self.curves[j].setData(col)
        self.plot_widget.setXRange(max(0, self.i - 100), self.i)
        self.i += 1

    def toggle_pause(self):
        self.paused = not self.paused
        if self.paused:
            self.pause_button.setText('Play')
        else:
            self.pause_button.setText('Pause')


def plot_data_tkinter(filename='raw.txt', num_columns=3):

    app = QApplication([])
    plot_window = PlotWindow(filename, num_columns)

    plot_widget = plot_window.plot_widget

    # Create a QWidget instance to use as the parent of the plot widget
    parent_widget = QWidget()

    win = tk.Toplevel()
    win.wm_title('My Plot')

    plot_widget.win = win

    # Pass the parent_widget instance to setParent() instead of win
    plot_widget.setParent(parent_widget)

    plot_widget.setGeometry(0, 0, 800, 600)

    win.protocol('WM_DELETE_WINDOW', app.quit)

    app.exec_()


if __name__ == '__main__':
    plot_data_tkinter() # Uses default filename and number of columns
